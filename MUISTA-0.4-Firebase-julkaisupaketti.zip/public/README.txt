MUISTA 0.4 – paikallinen PWA-testiversio

Avaa index.html selaimessa perustoimintojen kokeilemiseksi. PWA-asennus ja offline-välimuisti vaativat HTTPS-palvelimen (tai localhost-osoitteen). Julkaise kaikki kansion tiedostot samaan HTTPS-hakemistoon.

Ominaisuudet: henkilökohtaiset ja jaetut demotehtävät, simuloidut käyttäjät, oikeustasot, vastuuhenkilöt, kaikkien/ yhden kuittaus, toistuvuus, vastuuvuorottelu, teemat, JSON-varmuuskopiointi.

RAJOITUKSET: Ei kirjautumista, ei pilvisynkronointia, ei oikeita käyttäjäkutsuja, ei taustapush-ilmoituksia. Käyttäjien vaihto on vain käyttöliittymän testisimulaatio. Paikallista dataa ei tule pitää turvallisena oikeiden käyttäjien välisenä tietosuojarajana. Testi ei sovellu luottamuksellisten tehtävien tallentamiseen yhteiskäyttöiselle laitteelle.

Oikeat muistutukset ja Firebase-käyttöoikeussäännöt vaativat erillisen palvelintoteutuksen ja testauksen.
